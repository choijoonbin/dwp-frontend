---
name: DWP Workplace Operating System
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#434655'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#3755c3'
  on-secondary: '#ffffff'
  secondary-container: '#708cfd'
  on-secondary-container: '#00217a'
  tertiary: '#3e3fcc'
  on-tertiary: '#ffffff'
  tertiary-container: '#585be6'
  on-tertiary-container: '#f1eeff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#dde1ff'
  secondary-fixed-dim: '#b8c4ff'
  on-secondary-fixed: '#001453'
  on-secondary-fixed-variant: '#173bab'
  tertiary-fixed: '#e1e0ff'
  tertiary-fixed-dim: '#c0c1ff'
  on-tertiary-fixed: '#07006c'
  on-tertiary-fixed-variant: '#2f2ebe'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: Noto Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Noto Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Noto Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Noto Sans
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Noto Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Noto Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Noto Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  label-lg:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Geist
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
  metric-display:
    fontFamily: Geist
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

### Personality & Purpose
This design system governs high-density enterprise workplace platforms, resource scheduling, and operational telemetry. Built for knowledge workers, facility managers, and business operators, the interface evokes focus, absolute operational reliability, low cognitive fatigue, and procedural clarity.

### Aesthetic Movement: Corporate / Modern High-Density Utility
The visual paradigm balances Scandinavian functional minimalism with modern enterprise command centers:
- **Structural Discipline:** Rigid spatial alignment derived from explicit tabular layouts and strict layout boundaries.
- **Anti-Nesting Rule:** Eliminates recursive card-in-card patterns. Flat segmentation uses surface dividers, subtle 1px semantic borders, and background tonality rather than stacked nested containers.
- **Cognitive Hygiene:** Visual decoration is eradicated in favor of precise information scannability, status indicators, linear metrics, and real-time contextual feedback.

## Colors

The color palette is engineered strictly around semantic utility and WCAG 2.2 AA (minimum 4.5:1 for body copy, 3:1 for graphical UI elements) compliance over light substrates.

### Core Swatches
- **Primary Blue (`#2563eb`):** Primary action triggers, selected active navigation items, progress tracking highlights.
- **Dark / Deep Blue (`#1e40af`, `#1d4ed8`):** Focus ring outlines, primary hover states, critical emphasis text.
- **Surface Canvas (`#f8fafc`):** Main application workspace page canvas background.
- **Surface Elevation High (`#ffffff`):** Structural panels, content module containers, and elevation headers.
- **Structural Border (`#e2e8f0`):** Section perimeter lines, explicit split lines, and structural dividers.
- **Border Subdued (`#f1f5f9`):** Row striations and interior data table dividers.
- **Text Dominant (`#0f172a`):** Primary titles, operational metrics, and critical label states (contrast ratio 15.2:1 against white).
- **Text Supporting (`#475569`):** Secondary metadata, timestamps, contextual subtitles (contrast ratio 5.6:1 against white).
- **Text Disabled / Muted (`#94a3b8`):** Placeholder text, inactive counters, secondary auxiliary marks.

### Functional & Operational Telemetry
- **Operational Emerald (`#059669`):** Space available, verified check-in, completed intervals, positive availability badges (`#ecfdf5` background tint).
- **Warning Amber (`#d97706`):** Impending meeting start (<10 min), reservation expiry warning, pending check-in confirmation (`#fffbeb` background tint).
- **Critical Rose (`#e11d48`):** Immediate conflict, delayed release, system failure, action mandatory (`#fff1f2` background tint).
- **Focus Indigo / Rhythm (`#6366f1`):** Deep work blocks, focused analytical sessions, telemetry visualization tracks (`#eef2ff` background tint).

## Typography

Typography prioritizes multilingual precision and data legibility across dense dashboard grids.

### Font Roles
- **Noto Sans (CJK & Universal):** Applied across all primary headings, section intros, action labels, and standard narrative bodies. Prevents font-substitution jitter across localized Korean/English layouts.
- **Geist:** Applied across numeric displays, status indicators, badges, timetable values, timeline labels, and data table rows. Geist provides mono-like tabular numeral alignment (`tnum` feature active by default).

### Implementation Rules
- Tabular figures (`font-variant-numeric: tabular-nums`) must be enabled on all numerical values, capacity indicators, clock timestamps, and duration counters.
- Sub-labels and meta-indicators never drop below 11px to maintain legibility on non-Retina displays.
- Section titles should use tight negative tracking (`-0.01em` to `-0.02em`) to maintain authority and visual compactness.

## Layout & Spacing

### Shell Dimensions
- **Global Application Header:** Fixed height of `64px`, sticky to viewport top (`z-index: 50`).
- **Primary Side Navigation:** Fixed width of `248px`, full height beneath header (`z-index: 40`).
- **PageCanvas:** Fluid flex/grid area filling 100% of remaining horizontal width on `calc(100vh - 64px)`.

### Grid & Density Rules
- **Spacing Steps:** Internal margins adapt across strict breakpoints: `16px` (`space-md`), `24px` (`space-lg`), and `32px` (`space-xl`).
- **Desktop (>= 1280px):** 12-column grid with `16px` gutters and `24px` to `32px` canvas margins.
- **Tablet (768px - 1279px):** Sidebar collapses to icon-rail (`64px`), 8-column layout, `16px` gutters and margins.
- **Mobile (< 768px):** Sidebar converts to off-canvas modal drawer, 4-column single-stack flow, `16px` outer margin.

### Anti-Nesting Layout Architecture
Containers act as direct planar boundaries. Within an outer workspace section (e.g., Weekly Rhythm or Today's Flow), elements are organized via direct horizontal flex racks, grid arrays, or bordered list dividers. Do not embed elevated card wrappers inside another card wrapper.

## Elevation & Depth

This design system avoids heavy shadows and skeuomorphic blur in favor of structured architectural surface elevation and crisp boundary delineation.

### Elevation Levels
- **Level 0 (App Canvas):** `#f8fafc`. Recessed background layer hosting the structural shell.
- **Level 1 (Card & Module Panels):** `#ffffff`. Direct 1px solid border `#e2e8f0`, with subtle shadow `0 1px 2px 0 rgba(15, 23, 42, 0.04)`.
- **Level 2 (Dropdowns, Command Menus, Popovers):** `#ffffff`. 1px solid border `#cbd5e1`, shadow `0 4px 6px -1px rgba(15, 23, 42, 0.08), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`.
- **Level 3 (Modals, Space Reservers, Critical Drawers):** `#ffffff`. 1px solid border `#cbd5e1`, shadow `0 10px 15px -3px rgba(15, 23, 42, 0.1), 0 4px 6px -4px rgba(15, 23, 42, 0.05)`.

### Edge Treatments
All panel separators and inner modular sections must use hairline borders (`1px solid #e2e8f0`) rather than drop shadows to divide functional information segments.

## Shapes

The shape system is crisp and systematic (level 1 soft geometry), communicating high operational utility and professional precision without bubbly distortion.

### Corner Radii
- **Micro Tokens (`2px`):** Inline progress bar fills, status dots, metric progress tracks.
- **Small Tokens (`4px` / `0.25rem`):** Badges, status chips, tooltips, nested table controls.
- **Medium Tokens (`6px` to `8px` / `rounded-lg`):** Standard input fields, action buttons, filter triggers, command palette entries.
- **Structural Panels (`8px` to `12px` / `rounded-xl`):** Primary section surfaces, timeline blocks, weekly rhythm container modules.
- **Pills (`9999px`):** Exclusively reserved for notification count tags and avatar profile status indicators.

## Components

### Buttons
- **Primary:** Background `#2563eb`, border 1px solid `#1d4ed8`, text `#ffffff`, hover background `#1d4ed8`. Focus outline: 2px solid `#2563eb` with 2px offset.
- **Secondary / Ghost:** Background `#ffffff`, border 1px solid `#e2e8f0`, text `#0f172a`, hover background `#f8fafc` and border `#cbd5e1`.
- **Destructive:** Background `#ffffff`, border 1px solid `#fecdd3`, text `#e11d48`, hover background `#fff1f2`.

### Chips & Badges
- **Format:** Height `22px` to `24px`, font Geist `11px` or `12px` with `font-weight: 500`.
- **Available / Check-in:** Tinted green background `#ecfdf5`, text `#059669`, border 1px solid `#a7f3d0`.
- **Warning / Approaching:** Tinted amber background `#fffbeb`, text `#d97706`, border 1px solid `#fde68a`.
- **Urgent / Delayed:** Tinted rose background `#fff1f2`, text `#e11d48`, border 1px solid `#fecdd3`.
- **Telemetry / Focus:** Tinted blue/indigo background `#eff6ff`, text `#2563eb`, border 1px solid `#bfdbfe`.

### Form Fields & Inputs
- **Input Bars:** Height `36px` (compact enterprise density), background `#ffffff`, border `1px solid #e2e8f0`, placeholder `#94a3b8`, text `#0f172a`.
- **Focus State:** Border changes to `#2563eb`, accompanied by an outer box shadow ring of `0 0 0 3px rgba(37, 99, 235, 0.15)`.

### Cards & Sections (Flat Anti-Nesting Pattern)
- Outer section panels use white background `#ffffff` with a uniform perimeter border `1px solid #e2e8f0` and an 8px border radius.
- Internal segmenting is done using planar grid dividers (`border-r` or `border-b` with `#e2e8f0`) rather than nesting secondary cards inside parent cards.
- Selected or active states are marked with an interior 2px inset blue stroke `#2563eb` and tinted background `#eff6ff`.

### Weekly Rhythm & Telemetry Tracks
- **Track Heights:** `4px` continuous track line with background `#e2e8f0`.
- **Fills:** Dynamic width fills mapped to meeting time (`#2563eb`), deep work focus time (`#059669`), or conflict time (`#e11d48`).
- **Icons:** Standardized Lucide icon kit rendered at `14px` or `16px` with a consistent `1.5px` stroke width.